package utils;

import exceptions.RutInvalidoException;


public class ValidadorRut {


    public static void validar(String rut)
            throws RutInvalidoException {



        if(rut == null ||
           rut.trim().isEmpty()){


            throw new RutInvalidoException(
                    "El RUT no puede estar vacío."
            );

        }



        if(!rut.matches(
                "\\d{7,8}-[0-9Kk]"
        )){


            throw new RutInvalidoException(
                    "Formato inválido. Ejemplo: 12345678-9"
            );

        }



    }


}