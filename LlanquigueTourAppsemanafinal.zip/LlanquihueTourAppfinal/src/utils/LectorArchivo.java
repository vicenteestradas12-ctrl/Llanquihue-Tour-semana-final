package utils;

import data.GestorDatos;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import model.Cliente;
import model.Direccion;
import model.Rut;
import model.Tarjeta;


public class LectorArchivo {


    public static void cargarClientes(
            String ruta,
            GestorDatos gestor) {


        try(
            BufferedReader br =
            new BufferedReader(
                    new FileReader(ruta))
        ){


            String linea;



            while((linea = br.readLine()) != null){


                if(linea.trim().isEmpty()){

                    continue;

                }



                String[] datos =
                        linea.split(";");



                if(datos.length < 5){

                    continue;

                }



                Cliente cliente =
                        new Cliente(

                        datos[1],
                        datos[2],

                        new Rut(datos[0]),


                        new Direccion(
                                "Sin dirección",
                                "Llanquihue",
                                "Puerto Montt"
                        ),


                        new Tarjeta(
                                "BancoEstado",
                                "0000-0000"
                        ),


                        datos[3],

                        datos[4],

                        0

                );



                gestor.agregarCliente(cliente);


            }



            System.out.println(
                    "Clientes cargados correctamente."
            );



        }catch(IOException e){


            System.out.println(
                    "Error al leer archivo: "
                    + e.getMessage()
            );


        }


    }


}