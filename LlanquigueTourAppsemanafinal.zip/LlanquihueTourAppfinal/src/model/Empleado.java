package model;

import interfaces.Registrable;

public class Empleado extends Persona implements Registrable {

    private String cargo;

    public Empleado() {
    }

    public Empleado(String nombre, String apellido, Rut rut,
                     Direccion direccion, Tarjeta tarjeta,
                     String telefono, String correo,
                     String cargo) {

        super(nombre, apellido, rut, direccion, tarjeta, telefono, correo);
        this.cargo = cargo;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    @Override
    public void registrar() {
        System.out.println("Empleado registrado correctamente.");
    }

    @Override
    public void mostrarDatos() {
        System.out.println(this);
    }

    @Override
    public String toString() {

        return "===== EMPLEADO =====\n"
                + super.toString()
                + "\nCargo: " + cargo;
    }

}