package model;

import interfaces.Registrable;

public class Cliente extends Persona implements Registrable {

    private int puntos;

    public Cliente() {
    }

    public Cliente(String nombre, String apellido, Rut rut,
                   Direccion direccion, Tarjeta tarjeta,
                   String telefono, String correo,
                   int puntos) {

        super(nombre, apellido, rut, direccion, tarjeta, telefono, correo);
        this.puntos = puntos;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    @Override
    public void registrar() {
        System.out.println("Cliente registrado correctamente.");
    }

    @Override
    public void mostrarDatos() {
        System.out.println(this);
    }

    @Override
    public String toString() {
        return "===== CLIENTE =====\n"
                + super.toString()
                + "\nPuntos: " + puntos;
    }
}