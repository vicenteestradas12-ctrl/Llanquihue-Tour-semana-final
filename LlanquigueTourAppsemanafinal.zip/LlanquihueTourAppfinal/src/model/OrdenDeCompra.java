package model;

import java.util.ArrayList;

public class OrdenDeCompra {

    private int numeroOrden;
    private Cliente cliente;
    private ArrayList<ServicioTuristico> servicios;


    public OrdenDeCompra() {

        servicios = new ArrayList<>();

    }


    public OrdenDeCompra(int numeroOrden, Cliente cliente) {

        this.numeroOrden = numeroOrden;
        this.cliente = cliente;
        this.servicios = new ArrayList<>();

    }


    public int getNumeroOrden() {
        return numeroOrden;
    }


    public void setNumeroOrden(int numeroOrden) {
        this.numeroOrden = numeroOrden;
    }


    public Cliente getCliente() {
        return cliente;
    }


    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }


    public ArrayList<ServicioTuristico> getServicios() {
        return servicios;
    }


    public void agregarServicio(ServicioTuristico servicio) {

        servicios.add(servicio);

    }


    public double calcularTotal() {

        double total = 0;

        for (ServicioTuristico servicio : servicios) {

            total += servicio.getPrecio();

        }

        return total;

    }


    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder();


        sb.append("\n==============================");
        sb.append("\nORDEN N° ").append(numeroOrden);
        sb.append("\n==============================");


        if(cliente != null){

            sb.append("\nCliente: ")
              .append(cliente.getNombre())
              .append(" ")
              .append(cliente.getApellido());

        }


        sb.append("\n\nServicios contratados\n");


        for(ServicioTuristico servicio : servicios){

            sb.append("----------------------------\n");
            sb.append(servicio);
            sb.append("\n");

        }


        sb.append("\nTOTAL: $")
          .append(calcularTotal());


        return sb.toString();

    }

}