package model;

public class PaseoLacustre extends ServicioTuristico {

    private boolean incluyeNavegacion;

    public PaseoLacustre() {
    }

    public PaseoLacustre(String nombre,
                         double precio,
                         int duracionHoras,
                         boolean incluyeNavegacion) {

        super(nombre, precio, duracionHoras);
        this.incluyeNavegacion = incluyeNavegacion;
    }

    public boolean isIncluyeNavegacion() {
        return incluyeNavegacion;
    }

    public void setIncluyeNavegacion(boolean incluyeNavegacion) {
        this.incluyeNavegacion = incluyeNavegacion;
    }

    @Override
    public void mostrarInformacion() {
        System.out.println(this);
    }

    @Override
    public String toString() {

        return "=== Paseo Lacustre ===\n"
                + super.toString()
                + "\nIncluye navegación: "
                + (incluyeNavegacion ? "Sí" : "No");

    }

}