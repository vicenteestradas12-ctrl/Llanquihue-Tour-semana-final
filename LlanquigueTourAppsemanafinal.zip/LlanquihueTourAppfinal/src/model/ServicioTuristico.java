package model;

/**
 * Clase abstracta que representa un servicio turístico.
 */
public abstract class ServicioTuristico {

    private String nombre;
    private double precio;
    private int duracionHoras;


    public ServicioTuristico() {
    }


    public ServicioTuristico(String nombre,
                             double precio,
                             int duracionHoras) {

        this.nombre = nombre;
        this.precio = precio;
        this.duracionHoras = duracionHoras;
    }


    public String getNombre() {
        return nombre;
    }


    public void setNombre(String nombre) {
        this.nombre = nombre;
    }


    public double getPrecio() {
        return precio;
    }


    public void setPrecio(double precio) {
        this.precio = precio;
    }


    public int getDuracionHoras() {
        return duracionHoras;
    }


    public void setDuracionHoras(int duracionHoras) {
        this.duracionHoras = duracionHoras;
    }


    public abstract void mostrarInformacion();


    @Override
    public String toString() {

        return "Servicio: " + nombre
                + "\nPrecio: $" + precio
                + "\nDuración: " + duracionHoras + " horas";

    }

}