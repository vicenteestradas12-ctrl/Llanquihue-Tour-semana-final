package model;

public class ExcursionCultural extends ServicioTuristico {

    private String patrimonioVisitado;

    public ExcursionCultural() {
    }

    public ExcursionCultural(String nombre,
                             double precio,
                             int duracionHoras,
                             String patrimonioVisitado) {

        super(nombre, precio, duracionHoras);
        this.patrimonioVisitado = patrimonioVisitado;
    }

    public String getPatrimonioVisitado() {
        return patrimonioVisitado;
    }

    public void setPatrimonioVisitado(String patrimonioVisitado) {
        this.patrimonioVisitado = patrimonioVisitado;
    }

    @Override
    public void mostrarInformacion() {
        System.out.println(this);
    }

    @Override
    public String toString() {

        return "=== Excursión Cultural ===\n"
                + super.toString()
                + "\nPatrimonio: " + patrimonioVisitado;
    }

}