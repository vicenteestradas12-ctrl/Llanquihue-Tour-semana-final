package model;

public class RutaGastronomica extends ServicioTuristico {

    private int cantidadRestaurantes;

    public RutaGastronomica() {
    }

    public RutaGastronomica(String nombre,
                            double precio,
                            int duracionHoras,
                            int cantidadRestaurantes) {

        super(nombre, precio, duracionHoras);
        this.cantidadRestaurantes = cantidadRestaurantes;
    }

    public int getCantidadRestaurantes() {
        return cantidadRestaurantes;
    }

    public void setCantidadRestaurantes(int cantidadRestaurantes) {
        this.cantidadRestaurantes = cantidadRestaurantes;
    }

    @Override
    public void mostrarInformacion() {
        System.out.println(this);
    }

    @Override
    public String toString() {

        return "=== Ruta Gastronómica ===\n"
                + super.toString()
                + "\nRestaurantes: " + cantidadRestaurantes;
    }

}