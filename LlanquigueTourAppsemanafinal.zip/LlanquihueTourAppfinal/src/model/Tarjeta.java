package model;

public class Tarjeta {

    private String banco;
    private String numeroTarjeta;

    public Tarjeta() {
    }

    public Tarjeta(String banco, String numeroTarjeta) {
        this.banco = banco;
        this.numeroTarjeta = numeroTarjeta;
    }

    public String getBanco() {
        return banco;
    }

    public void setBanco(String banco) {
        this.banco = banco;
    }

    public String getNumeroTarjeta() {
        return numeroTarjeta;
    }

    public void setNumeroTarjeta(String numeroTarjeta) {
        this.numeroTarjeta = numeroTarjeta;
    }

    @Override
    public String toString() {
        return banco + " - " + numeroTarjeta;
    }
}