package model;

import interfaces.Registrable;

public class Proveedor extends Persona implements Registrable {

    private String empresa;

    public Proveedor() {
    }

    public Proveedor(String nombre, String apellido,
                     Rut rut,
                     Direccion direccion,
                     Tarjeta tarjeta,
                     String telefono,
                     String correo,
                     String empresa) {

        super(nombre, apellido, rut, direccion, tarjeta, telefono, correo);
        this.empresa = empresa;
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    @Override
    public void registrar() {
        System.out.println("Proveedor registrado.");
    }

    @Override
    public void mostrarDatos() {
        System.out.println(this);
    }

    @Override
    public String toString() {

        return "===== PROVEEDOR =====\n"
                + super.toString()
                + "\nEmpresa: " + empresa;
    }

}