package app;

import data.GestorDatos;
import exceptions.RutInvalidoException;

import java.util.Scanner;

import model.Cliente;
import model.Direccion;
import model.OrdenDeCompra;
import model.Rut;
import model.Tarjeta;

import utils.LectorArchivo;
import utils.ValidadorRut;


public class Main {


    public static void main(String[] args) {


        Scanner scanner = new Scanner(System.in);

        GestorDatos gestor = new GestorDatos();


        int opcion;



        do {


            System.out.println("\n======================================");
            System.out.println("        SISTEMA LLANQUIHUE TOUR");
            System.out.println("======================================");

            System.out.println("1. Registrar cliente");
            System.out.println("2. Buscar cliente por RUT");
            System.out.println("3. Mostrar clientes");
            System.out.println("4. Cargar clientes desde TXT");
            System.out.println("5. Mostrar servicios turísticos");
            System.out.println("6. Registrar orden de compra");
            System.out.println("7. Mostrar historial de órdenes");
            System.out.println("0. Salir");


            System.out.print(
                    "Seleccione una opción: "
            );


            opcion = scanner.nextInt();
            scanner.nextLine();



            switch(opcion) {



                // ==========================
                // REGISTRAR CLIENTE
                // ==========================

                case 1:


                    System.out.print("Nombre: ");
                    String nombre =
                            scanner.nextLine();



                    System.out.print("Apellido: ");
                    String apellido =
                            scanner.nextLine();



                    System.out.print("RUT: ");
                    String rutTexto =
                            scanner.nextLine();



                    try {


                        ValidadorRut.validar(rutTexto);



                    } catch(RutInvalidoException e) {


                        System.out.println(
                                e.getMessage()
                        );

                        break;

                    }



                    System.out.print("Teléfono: ");
                    String telefono =
                            scanner.nextLine();



                    System.out.print("Correo: ");
                    String correo =
                            scanner.nextLine();



                    Cliente cliente =
                            new Cliente(

                                    nombre,

                                    apellido,

                                    new Rut(rutTexto),


                                    new Direccion(
                                            "Sin dirección",
                                            "Llanquihue",
                                            "Puerto Montt"
                                    ),


                                    new Tarjeta(
                                            "BancoEstado",
                                            "0000-0000"
                                    ),


                                    telefono,

                                    correo,

                                    0

                            );



                    gestor.agregarCliente(cliente);



                    break;



                // ==========================
                // BUSCAR CLIENTE
                // ==========================

                case 2:


                    System.out.print(
                            "Ingrese RUT: "
                    );


                    String rutBuscar =
                            scanner.nextLine();



                    Cliente encontrado =
                            gestor.buscarCliente(
                                    rutBuscar
                            );



                    if(encontrado != null){


                        System.out.println(
                                encontrado
                        );


                    }else{


                        System.out.println(
                                "Cliente no encontrado."
                        );


                    }


                    break;




                // ==========================
                // MOSTRAR CLIENTES
                // ==========================

                case 3:


                    gestor.mostrarClientes();


                    break;




                // ==========================
                // CARGAR ARCHIVO TXT
                // ==========================

                case 4:


                    LectorArchivo.cargarClientes(

                            "src/data/clientes.txt",

                            gestor

                    );


                    break;




                // ==========================
                // MOSTRAR SERVICIOS
                // ==========================

                case 5:


                    gestor.mostrarServicios();


                    break;




                // ==========================
                // REGISTRAR ORDEN
                // ==========================

                case 6:


                    System.out.print(
                            "Ingrese RUT del cliente: "
                    );


                    String rutOrden =
                            scanner.nextLine();



                    Cliente clienteOrden =
                            gestor.buscarCliente(
                                    rutOrden
                            );



                    if(clienteOrden == null){


                        System.out.println(
                                "Cliente no encontrado."
                        );


                        break;

                    }



                    OrdenDeCompra orden =
                            new OrdenDeCompra(

                                    gestor.getHistorialOrdenes().size()
                                            + 1,

                                    clienteOrden

                            );



                    /*
                    Se agregan servicios existentes
                    del catálogo de GestorDatos
                    */


                    orden.agregarServicio(
                            gestor.getServicios().get(0)
                    );



                    orden.agregarServicio(
                            gestor.getServicios().get(1)
                    );



                    orden.agregarServicio(
                            gestor.getServicios().get(2)
                    );



                    gestor.registrarOrden(
                            orden
                    );



                    System.out.println(
                            "Orden registrada correctamente."
                    );



                    break;




                // ==========================
                // HISTORIAL
                // ==========================

                case 7:


                    gestor.mostrarHistorial();


                    break;




                // ==========================
                // SALIR
                // ==========================

                case 0:


                    System.out.println(
                            "\nGracias por utilizar Llanquihue Tour."
                    );


                    break;




                default:


                    System.out.println(
                            "Opción no válida."
                    );


            }



        }while(opcion != 0);



        scanner.close();


    }


}