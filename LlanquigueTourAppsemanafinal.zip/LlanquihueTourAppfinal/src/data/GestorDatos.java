package data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Stack;

import model.Cliente;
import model.ExcursionCultural;
import model.OrdenDeCompra;
import model.PaseoLacustre;
import model.RutaGastronomica;
import model.ServicioTuristico;

public class GestorDatos {


    private ArrayList<Cliente> clientes;
    private ArrayList<ServicioTuristico> servicios;
    private HashMap<String, Cliente> mapaClientes;
    private Stack<OrdenDeCompra> historialOrdenes;


    public GestorDatos() {

        clientes = new ArrayList<>();
        servicios = new ArrayList<>();
        mapaClientes = new HashMap<>();
        historialOrdenes = new Stack<>();

        cargarServiciosIniciales();

    }


    // ===============================
    // CLIENTES
    // ===============================


    public void agregarCliente(Cliente cliente) {


        String rut = cliente.getRut().getNumero();


        if(!mapaClientes.containsKey(rut)){


            clientes.add(cliente);

            mapaClientes.put(rut, cliente);


            System.out.println(
                    "Cliente agregado correctamente."
            );


        }else{


            System.out.println(
                    "El cliente ya existe."
            );

        }

    }



    public Cliente buscarCliente(String rut) {

        return mapaClientes.get(rut);

    }



    public void mostrarClientes() {


        if(clientes.isEmpty()){

            System.out.println(
                    "\nNo existen clientes registrados."
            );

            return;

        }


        for(Cliente cliente : clientes){

            System.out.println("----------------------------");
            System.out.println(cliente);

        }

    }



    // ===============================
    // SERVICIOS
    // ===============================


    public void agregarServicio(ServicioTuristico servicio){

        servicios.add(servicio);

    }



    private void cargarServiciosIniciales(){


        servicios.add(
                new RutaGastronomica(
                        "Ruta Gastronómica Puerto Varas",
                        45000,
                        6,
                        5
                )
        );


        servicios.add(
                new PaseoLacustre(
                        "Paseo Lago Llanquihue",
                        30000,
                        4,
                        true
                )
        );


        servicios.add(
                new ExcursionCultural(
                        "Excursión Frutillar",
                        28000,
                        5,
                        "Museo Colonial Alemán"
                )
        );


        servicios.add(
                new RutaGastronomica(
                        "Ruta del Salmón",
                        38000,
                        5,
                        3
                )
        );

    }



    public void mostrarServicios(){


        if(servicios.isEmpty()){


            System.out.println(
                    "\nNo existen servicios registrados."
            );

            return;

        }



        for(ServicioTuristico servicio : servicios){


            System.out.println(
                    "--------------------------------"
            );


            if(servicio instanceof RutaGastronomica){

                System.out.println(
                        "Tipo: Ruta Gastronómica"
                );


            }else if(servicio instanceof PaseoLacustre){


                System.out.println(
                        "Tipo: Paseo Lacustre"
                );


            }else if(servicio instanceof ExcursionCultural){


                System.out.println(
                        "Tipo: Excursión Cultural"
                );

            }



            servicio.mostrarInformacion();


        }


    }



    // ===============================
    // ORDENES
    // ===============================


    public void registrarOrden(OrdenDeCompra orden){

        historialOrdenes.push(orden);

    }



    public void mostrarHistorial(){


        if(historialOrdenes.isEmpty()){


            System.out.println(
                    "\nNo existen órdenes registradas."
            );

            return;

        }



        for(OrdenDeCompra orden : historialOrdenes){


            System.out.println("----------------------------");

            System.out.println(orden);


        }

    }



    // ===============================
    // GETTERS
    // ===============================


    public ArrayList<Cliente> getClientes(){

        return clientes;

    }



    public ArrayList<ServicioTuristico> getServicios(){

        return servicios;

    }



    public Stack<OrdenDeCompra> getHistorialOrdenes(){

        return historialOrdenes;

    }


}